

    // Dados das obras separados por status
    const obras = [
        { nome: "Obra 1", status: "ativa", imagem: "https://via.placeholder.com/300x400 ", descricao: "Descrição da Obra 1" },
		{ nome: "Obra 2", status: "ativa", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 2" },
		{ nome: "Obra 3", status: "ativa", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 3" },
		{ nome: "Obra 4", status: "ativa", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 4" },
        { nome: "Obra 1", status: "pausada", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 1" },
		{ nome: "Obra 2", status: "pausada", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 2" },
		{ nome: "Obra 3", status: "pausada", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 3" },
		{ nome: "Obra 4", status: "pausada", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 4" },
        { nome: "Obra 1", status: "finalizada", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 1" },
		{ nome: "Obra 2", status: "finalizada", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 2" },
		{ nome: "Obra 3", status: "finalizada", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 3" },
		{ nome: "Obra 4", status: "finalizada", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 4" },
		{ nome: "Obra 1", status: "cancelado", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 1" },
		{ nome: "Obra 2", status: "cancelado", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 2" },
		{ nome: "Obra 3", status: "cancelado", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 3" },
		{ nome: "Obra 4", status: "cancelado", imagem: "https://via.placeholder.com/300x400", descricao: "Descrição da Obra 4" },
        // Adicione mais obras conforme necessário para cada status
    ];

    // Função para criar um slide de obra com imagem, nome e descrição
    function criarSlideObra(nomeObra, imagemObra, descricaoObra) {
        const slide = document.createElement('div');
        slide.classList.add('obra');
        const img = document.createElement('img');
        img.src = imagemObra;
        img.alt = nomeObra;
        const nome = document.createElement('h3');
        nome.textContent = nomeObra;
        const descricao = document.createElement('p');
        descricao.textContent = descricaoObra;
        slide.appendChild(img);
        slide.appendChild(nome);
        slide.appendChild(descricao);
        return slide;
    }

    // Organizando as obras por status
    const ativasCarousel = $("#ativasCarousel");
    const pausadasCarousel = $("#pausadasCarousel");
    const finalizadasCarousel = $("#finalizadasCarousel");
	const canceladoCarousel = $("#canceladoCarousel");

    obras.forEach(obra => {
        const slideObra = criarSlideObra(obra.nome, obra.imagem, obra.descricao);
        switch (obra.status) {
            case 'ativa':
                ativasCarousel.append(slideObra);
                break;
            case 'pausada':
                pausadasCarousel.append(slideObra);
                break;
            case 'finalizada':
                finalizadasCarousel.append(slideObra);
                break;
		    case 'cancelado':
                canceladoCarousel.append(slideObra);
                break;
            default:
                break;
        }
    });

    // Inicialização dos carrosséis usando a biblioteca Slick Carousel
    $('.carousel').slick({
        dots: true,
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 3
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 3
                }
            }
        ]
    });
  // Função para voltar para a página principal
    function voltarParaPaginaPrincipal() {
        window.location.href = "../../../index.html"; // Substitua pelo caminho da sua página principal
    }
	