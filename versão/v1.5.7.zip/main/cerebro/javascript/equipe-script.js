function voltarParaPaginaInicial() {
        window.location.href = "../../../index.html";
    }

window.addEventListener('resize', () => {
    ajustarLayoutResponsivo();
});
    const equipe = [
       {
            nome: "Membro 01",
            cargo: "tradução",
            descricao: "Responsável pela tradução",
            imagem: "https://via.placeholder.com/150", 
                social: {
                instagram: "#",
            }
        },
        {
            nome: "Membro 02",
            cargo: "type",
            descricao: "Responsável pelo não sei",
            imagem: "https://via.placeholder.com/150", 
            social: {
                instagram: "#",
            }
        },
        {
            nome: "Membro 03",
            cargo: "Revisão",
            descricao: "Responsável pela Revisão",
            imagem: "https://via.placeholder.com/150", 
            social: {
                instagram: "#",
            }
			}
			,
			{
            nome: "Membro 04",
            cargo: "Q.C",
            descricao: "Responsável pela não sei",
            imagem: "https://via.placeholder.com/150", 
            social: {
                instagram: "#",
            }
			}
			,
			{
            nome: "Membro 05",
            cargo: "Cleaner",
            descricao: "Responsável pela limpesar",
            imagem: "https://via.placeholder.com/150", 
            social: {
                instagram: "#",
            }
			}
			,
			{
            nome: "Membro 06",
            cargo: "Redraw",
            descricao: "Responsável pela não sei ",
            imagem: "https://via.placeholder.com/150", 
            social: {
                instagram: "#",
            }
			}
        // Adicione os demais membros da equipe da mesma forma
    ];

  
    function exibirEquipeEmColunas() {
        const teamContainer = document.getElementById('team');
        let currentRow = null;

        equipe.forEach((membro, index) => {
            if (index % 3 === 0) {
                currentRow = document.createElement('div');
                currentRow.classList.add('team-row');
                teamContainer.appendChild(currentRow);
            }

            const memberDiv = document.createElement('div');
            memberDiv.classList.add('team-member');

            const imagem = document.createElement('img');
            imagem.src = membro.imagem;
            imagem.alt = membro.nome;

            const infoDiv = document.createElement('div');
            infoDiv.classList.add('member-info');

            const nome = document.createElement('h2');
            nome.textContent = membro.nome;

            const cargo = document.createElement('h3');
            cargo.textContent = membro.cargo;

            const descricao = document.createElement('p');
            descricao.textContent = membro.descricao;

            const socialIcons = document.createElement('div');
            socialIcons.classList.add('social-icons');

            for (const [redeSocial, link] of Object.entries(membro.social)) {
                const socialLink = document.createElement('a');
                socialLink.href = link;
                socialLink.setAttribute('target', '_blank'); // Abrir em uma nova aba
                socialLink.textContent = redeSocial.charAt(0).toUpperCase();
                socialIcons.appendChild(socialLink);
            }

            infoDiv.appendChild(nome);
            infoDiv.appendChild(cargo);
            infoDiv.appendChild(descricao);
            infoDiv.appendChild(socialIcons);

            memberDiv.appendChild(imagem);
            memberDiv.appendChild(infoDiv);

            currentRow.appendChild(memberDiv);
        });
    }

   
    exibirEquipeEmColunas();
