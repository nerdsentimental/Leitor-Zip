const manhuaContainer = document.getElementById('manhua-container');
const imageFolder = '../../leitor/';

const numPages = 15;
const images = Array.from({ length: numPages }, (_, i) => `${i + 1}.jpg`);

let currentPage = 0;
let singlePageMode = true;

function loadPage(page) {
    const maxWidth = 800; // Defina a largura máxima desejada
    const imageSrc = `${imageFolder}${images[page]}`;
    
    const windowWidth = window.innerWidth;
    const imageWidth = windowWidth > maxWidth ? maxWidth : windowWidth * 0.9;
    const imageHeight = (imageWidth / maxWidth) * (maxWidth / images.length) * 1.5;

    manhuaContainer.innerHTML = `<img src="${imageSrc}" alt="Página ${page + 1}" style="max-width: ${imageWidth}px; height: auto;">`;
}

function next() {
    if (currentPage < images.length - 1) {
        currentPage++;
        loadPage(currentPage);
    }
}

function prev() {
    if (currentPage > 0) {
        currentPage--;
        loadPage(currentPage);
    }
}

function toggleMode() {
    singlePageMode = !singlePageMode;
    if (singlePageMode) {
        loadPage(currentPage);
    } else {
        loadScrollMode();
    }
}

function loadScrollMode() {
    let scrollModeHtml = '';
    const maxWidth = 800; // Defina a largura máxima desejada

    for (let i = 0; i < images.length; i++) {
        const imageWidth = window.innerWidth > maxWidth ? maxWidth : window.innerWidth * 0.9;
        const imageHeight = (imageWidth / maxWidth) * (maxWidth / images.length) * 1.5;
        const imageSrc = `${imageFolder}${images[i]}`;
        
        scrollModeHtml += `<img src="${imageSrc}" alt="Página ${i + 1}" style="max-width: ${imageWidth}px; height: auto;">`;
    }

    manhuaContainer.innerHTML = scrollModeHtml;
}

manhuaContainer.addEventListener('click', (event) => {
    const { clientX } = event;
    const containerWidth = manhuaContainer.offsetWidth;

    if (singlePageMode) {
        // Somente ative a navegação por clique no modo de página única
        if (clientX < containerWidth / 2) {
            prev();
        } else {
            next();
        }
    }
});

function toggleMode() {
    singlePageMode = !singlePageMode;
    if (singlePageMode) {
        loadPage(currentPage);
        // Ative o clique novamente ao retornar ao modo de página única
        manhuaContainer.addEventListener('click', clickHandler);
    } else {
        loadScrollMode();
        // Remova o clique ao entrar no modo de rolagem
        manhuaContainer.removeEventListener('click', clickHandler);
    }
}

function clickHandler(event) {
    const { clientX } = event;
    const containerWidth = manhuaContainer.offsetWidth;

    if (clientX < containerWidth / 2) {
        prev();
    } else {
        next();
    }
}

document.addEventListener('keydown', (event) => {
    if (event.key === 'ArrowRight') {
        next();
    } else if (event.key === 'ArrowLeft') {
        prev();
    }
});


// Função para voltar para a página inicial
function voltarPaginaInicial() {
window.location.href = '../../../index.html'; // Substitua 'link_para_pagina_inicial' pela URL da sua página inicial
   }

// Carregue a primeira página ao carregar a página
loadPage(currentPage);

